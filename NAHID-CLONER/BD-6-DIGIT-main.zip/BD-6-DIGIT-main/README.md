## <b>Screenshot</b>
<a href="https://github.com/PSYCHO-PICCHI/"><img src="https://i.ibb.co/GpnjGbf/20220326-121013.jpg" alt="20220326-121013" border="0"></a>

## <b>installation</b>
```
🔗 pkg update
🔗 pkg upgrade
🔗 pkg install python
🔗 pkg install python2
🔗 pip2 install requests
🔗 pip2 install mechanize
🔗 pkg install git
🔗 git clone https://github.com/PSYCHO-PICCHI/BD-6-DIGIT.git
🔗 cd BD-6-DIGIT
🔗 python2 Psycho.py

🖤 Thank you For Using My Tools 🖤

```

# Single Command 

```
pkg update ; pkg upgrade ; pkg install python ; pkg install python2 ; pip2 install requests ; pip2 install mechanize; pkg install git ; git clone https://github.com/PSYCHO-PICCHI/BD-6-DIGIT.git ; cd BD-6-DIGIT; python2 Psycho.py
```
<br/>
      <a href="https://github.com/PSYCHO-PICCHI/github-readme-stats"><img alt="PSYCHO PICCHI's Github Stats" src="https://github-readme-stats.vercel.app/api?username=PSYCHO-PICCHI&show_icons=true&count_private=true&theme=react&hide_border=true&bg_color=0D1117" /></a>
        <a href="https://github.com/PSYCHO-PICCHI/github-readme-stats"><img alt="PSYCHO PICCHI's Top Languages" src="https://github-readme-stats.vercel.app/api/top-langs/?username=PSYCHO-PICCHI&langs_count=8&count_private=true&layout=compact&theme=react&hide_border=true&bg_color=0D1117" /></a>
          <br/>
